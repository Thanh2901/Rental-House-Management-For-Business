const Footer = () =>{

    return(
        <footer className="my-footer">
            <span> Phegon Hotel | All Rights Reserved &copy; 2025</span>
        </footer>
    )

}
export default Footer;