package com.example.HotelBooking.enums;

public enum PaymentStatus {
    PENDING, COMPLETED, FAILED, REFUNDED, REVERSED
}
