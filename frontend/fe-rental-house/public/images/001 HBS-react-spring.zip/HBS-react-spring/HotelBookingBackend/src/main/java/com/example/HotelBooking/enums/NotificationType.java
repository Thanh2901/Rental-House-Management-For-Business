package com.example.HotelBooking.enums;

public enum NotificationType {
    EMAIL, SMS, WHASTSAPP
}
