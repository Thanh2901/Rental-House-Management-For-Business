package com.example.HotelBooking.enums;

public enum RoomType {
    SINGLE, DOUBLE, SUIT, TRIPLE
}
