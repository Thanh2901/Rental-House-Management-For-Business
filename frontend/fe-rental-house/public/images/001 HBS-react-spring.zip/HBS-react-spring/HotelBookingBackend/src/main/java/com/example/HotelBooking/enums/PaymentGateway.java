package com.example.HotelBooking.enums;

public enum PaymentGateway {
    PAYPAL, STRIPE, PAYSTACK, FLUTTERWAVE
}
