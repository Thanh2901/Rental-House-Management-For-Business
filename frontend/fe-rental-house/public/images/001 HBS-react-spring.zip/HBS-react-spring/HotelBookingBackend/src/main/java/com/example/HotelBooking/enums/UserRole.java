package com.example.HotelBooking.enums;

public enum UserRole {
    CUSTOMER, ADMIN
}
