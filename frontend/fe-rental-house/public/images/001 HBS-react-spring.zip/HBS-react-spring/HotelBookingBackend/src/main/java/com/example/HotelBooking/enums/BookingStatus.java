package com.example.HotelBooking.enums;

public enum BookingStatus {
    BOOKED, CHECKED_IN, CHECKED_OUT, CANCELLED
}
